# Release Crypto Website

Simple static HTML/CSS/JS site to confirm payment and enter trading password.

## How to use

1. Open `index.html` in any web browser.
2. Or host it on GitHub Pages.